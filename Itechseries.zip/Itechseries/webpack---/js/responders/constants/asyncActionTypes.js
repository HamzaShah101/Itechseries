'use es6';

import {
    createAsyncActionTypes
} from 'conversations-async-data/async-action/createAsyncActionTypes';
export const FETCH_AGENT_RESPONDER = createAsyncActionTypes('FETCH_AGENT_RESPONDER');