'use es6';

import getIn from 'transmute/getIn';
export const getResponders = getIn(['responders']);