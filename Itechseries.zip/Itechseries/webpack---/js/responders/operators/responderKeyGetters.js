'use es6';

import getIn from 'transmute/getIn';
export const getId = getIn(['senderId']);
export const getType = getIn(['senderType']);