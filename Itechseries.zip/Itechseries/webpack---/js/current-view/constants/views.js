'use es6';

export const THREAD_LIST = 'thread-list';
export const THREAD_VIEW = 'thread-view';
export const KNOWLEDGE_BASE = 'knowledge-base';