'use es6';

export const UPDATE_VIEW = 'UPDATE_VIEW';