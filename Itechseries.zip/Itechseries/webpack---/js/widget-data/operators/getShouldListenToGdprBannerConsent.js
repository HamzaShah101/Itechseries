'use es6';

import get from 'transmute/get';
export const getShouldListenToGdprBannerConsent = data => get('shouldListenToGdprBannerConsent', data);