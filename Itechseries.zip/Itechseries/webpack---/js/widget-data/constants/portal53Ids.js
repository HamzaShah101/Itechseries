'use es6';

export const PORTAL_53_ID = 53;
export const PORTAL_53_QA_ID = 99535353;