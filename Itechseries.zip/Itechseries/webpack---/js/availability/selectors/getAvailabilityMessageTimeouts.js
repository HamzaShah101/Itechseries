'use es6';

import get from 'transmute/get';
const getAvailabilityMessageTimeouts = get('availabilityMessageTimeouts');
export {
    getAvailabilityMessageTimeouts as
    default, getAvailabilityMessageTimeouts
};