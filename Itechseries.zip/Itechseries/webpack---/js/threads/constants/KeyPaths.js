'use es6';

export const ASSIGNED_AGENT_ID = ['assignedAgentId'];
export const ASSIGNEE = ['assignedAgentId'];
export const CHANNEL_DETAILS = ['channelDetails'];
export const LATEST_MESSAGE_TIMESTAMP = ['latestMessageTimestamp'];
export const LATEST_READ_TIMESTAMP = ['latestReadTimestamp'];
export const PREVIEW_MESSAGE_ID = ['previewMessageId'];
export const RESPONDER = ['responder'];
export const SOURCE = ['source'];
export const STATUS = ['status'];
export const THREAD_ID = ['threadId'];
export const UNSEEN_COUNT = ['unseenCount'];