'use es6';

export const STUBBED_THREAD_ID = 0;