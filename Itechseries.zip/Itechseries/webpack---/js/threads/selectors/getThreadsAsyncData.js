'use es6';

import get from 'transmute/get';
export const getThreadsAsyncData = state => get('threads', state);