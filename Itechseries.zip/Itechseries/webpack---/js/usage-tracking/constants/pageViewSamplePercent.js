'use es6';

export const PAGEVIEW_SAMPLE_PERCENT = 0.1;