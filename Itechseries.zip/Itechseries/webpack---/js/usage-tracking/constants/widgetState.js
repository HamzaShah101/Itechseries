'use es6';

export const ONLINE = 'online';
export const OFFLINE = 'offline;';