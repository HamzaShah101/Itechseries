'use es6';

export const EXTERNAL_API_EVENT = 'external-api-event';