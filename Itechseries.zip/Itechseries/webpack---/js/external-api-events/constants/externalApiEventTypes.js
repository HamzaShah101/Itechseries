'use es6';

export const CONVERSATION_STARTED = 'conversationStarted';
export const CONVERSATION_CLOSED = 'conversationClosed';
export const UNREAD_CONVERSATION_COUNT_CHANGED = 'unreadConversationCountChanged';
export const INPUT_STAGING = 'inputStaging';
export const CONTACT_ASSOCIATED = 'contactAssociated';