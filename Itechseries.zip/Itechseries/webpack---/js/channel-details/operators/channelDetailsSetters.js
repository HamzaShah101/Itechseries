'use es6';

import set from 'transmute/set';
export const setChannelName = set('name');
export const setChannelType = set('type');