'use es6';

import get from 'transmute/get';
export const getChannelName = get('name');
export const getChannelType = get('type');