'use es6';

import {
    Record
} from 'immutable';
export default Record({
    name: null,
    type: null
}, 'ChannelDetails');