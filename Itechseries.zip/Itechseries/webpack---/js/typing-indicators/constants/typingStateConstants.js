'use es6';

export const TYPING_INDICATOR_TIMEOUT_MS = 5500;