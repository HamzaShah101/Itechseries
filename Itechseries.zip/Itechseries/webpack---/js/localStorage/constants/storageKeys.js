'use es6';

export const localStorageKeys = {
    HUBLYTICS_EVENTS_53: 'HUBLYTICS_EVENTS_53',
    HMPL: '__hmpl'
};