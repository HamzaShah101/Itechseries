'use es6';

import {
    createAsyncActionTypes
} from 'conversations-async-data/async-action/createAsyncActionTypes';
export const CREATE_NEW_THREAD = createAsyncActionTypes('CREATE_NEW_THREAD');