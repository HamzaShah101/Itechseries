'use es6';

export const getWidgetUiState = state => state.widgetUi;