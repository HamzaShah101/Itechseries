'use es6';

export const getIsInForeground = state => state.clientData.isInForeground;