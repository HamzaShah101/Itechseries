"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RESET_WIDGET = void 0;
const RESET_WIDGET = 'resetWidget';
exports.RESET_WIDGET = RESET_WIDGET;