'use es6';

export const LIVE_CHAT_GENERIC_CHANNEL_ID = 1000;