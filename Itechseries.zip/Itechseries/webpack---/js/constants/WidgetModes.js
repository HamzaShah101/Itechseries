'use es6';

export const PREVIEW = 'preview';
export const STANDARD = 'STANDARD';