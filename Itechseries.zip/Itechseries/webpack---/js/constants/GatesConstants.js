'use es6';

export const PERSISTED_AUTOMATED_MESSAGES = 'Conversations:PersistedAutomatedMessagesV2';
export const WORKER_EXPERIMENT = 'Conversations:WorkerPublishExperiment';