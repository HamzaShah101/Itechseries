'use es6';

export const API_TRACKING_EVENT_NAMES = ['HubspotConversations-hsConversationsOnReady-used', 'HubspotConversations-hsConversationsSettings-used', 'HubspotConversations-api-method-used', 'HubspotConversations-api-event-listener-registered'];