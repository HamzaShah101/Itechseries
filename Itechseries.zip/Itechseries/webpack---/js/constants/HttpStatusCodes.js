'use es6';

export const OK = 200;
export const NO_CONTENT = 204;
export const GONE = 410;