'use es6';

import get from 'transmute/get';
export const getGlobalCookieOptOut = get('globalCookieOptOut');