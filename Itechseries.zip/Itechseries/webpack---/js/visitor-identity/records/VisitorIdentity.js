'use es6';

import {
    Record
} from 'immutable';
export default Record({
    globalCookieOptOut: null,
    isFirstVisitorSession: true
}, 'VisitorIdentity');