'use es6';

import {
    createAsyncActionTypes
} from 'conversations-async-data/async-action/createAsyncActionTypes';
export const RESOLVE_ATTACHMENTS = createAsyncActionTypes('RESOLVE_ATTACHMENTS');