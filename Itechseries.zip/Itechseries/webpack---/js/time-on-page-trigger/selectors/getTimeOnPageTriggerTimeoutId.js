'use es6';

import getIn from 'transmute/getIn';
export const getTimeOnPageTriggerTimeoutId = getIn(['timeOnPageTrigger', 'timeoutId']);